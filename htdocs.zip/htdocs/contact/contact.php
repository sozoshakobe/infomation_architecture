<?php

/*
PHP お問い合わせフォーム
- - - - - - - 
創造社デザイン専門学校　情報アーキテクチャー　授業資料
お問い合わせ送信プログラム

担当　尾崎卓治
*/

/*基本情報*/
require_once('./config.php');
$dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8',DB_HOST,DB_NAME);

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    //データ送信モード

    //request data取得
    if(isset($_POST['FLG']) && $_POST['FLG'] == "sozosha"){
        $user_name = htmlspecialchars($_POST['user_name']);
        $user_mail = htmlspecialchars($_POST['user_mail']);
        $message = htmlspecialchars($_POST['message']);

        //どれか一つでも空欄だった場合はお問い合わせページにリダイレクト
        if($user_name == "" || $user_mail == "" || $message == ""){
            header('location:./contact.html');
        }else{
            //登録内容の保存
            try {
                $pdo = new PDO($dsn,DB_USER,DB_PASSWORD);

                $stmt = $pdo -> prepare("INSERT INTO contact (user_name, user_mail,message,created_at) VALUES (:user_name, :user_mail,:message,now())");
                $stmt->bindParam(':user_name', $user_name, PDO::PARAM_STR);
                $stmt->bindValue(':user_mail', $user_mail, PDO::PARAM_STR);
                $stmt->bindValue(':message', $message, PDO::PARAM_STR);
                $stmt->execute();
                if($stmt){
                    header('location:'.THANKS_PAGE);
                }else{
                    header('location:'.ERROR_PAGE);
                }
            }catch(PDOException $e){
                print('ERROR:'.$e->getMessage());
                header('location:'.ERROR_PAGE);
            }
        }
    } else {
        //request dataが取得出来なかったため、トップページにリダイレクト
        header('location:./');
        exit;
    }
}else{
   //動作確認モード
   if(isset($_GET['mode'])&& $_GET['mode']==='test'){
        
        echo 'TEST MODE:OK','<br>',PHP_EOL;
        echo 'PHP Version:',phpversion(),'<br>',PHP_EOL;
        echo 'MySQL Status:',db_connect_chk(),'<br>',PHP_EOL;

   } else{
       //トップページにリダイレクト
       header('location:./');
       exit;
   }
}

function db_connect_chk(){
    try {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8',DB_HOST,DB_NAME);
        $pdo = new PDO($dsn,DB_USER,DB_PASSWORD);
        $connect_status = "MySQL接続OK";
    }catch(PDOException $e){
        print('ERROR:'.$e->getMessage());
        $connect_status = "MySQL接続NG";
    }
    return $connect_status;
}
