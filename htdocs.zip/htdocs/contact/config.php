<?php
//MAMP用
define('DB_HOST', 'localhost:8889');//DBホスト
define('DB_USER', 'root');//ユーザー名
define('DB_PASSWORD', 'root');//ユーザーパスワード
define('DB_NAME', 'contact');//DB名
define('THANKS_PAGE','./thanks.html');//送信成功ページ
define('ERROR_PAGE','./error.html');//送信成功ページ
define('ADMINPASS','abcd1234');//サインインパスワード