<?php

/*
PHP お問い合わせフォーム
- - - - - - - 
創造社デザイン専門学校　情報アーキテクチャー　授業資料
お問い合わせ管理プログラム

担当　尾崎卓治
*/

/*基本情報*/
require_once('./config.php');
//処理情報
$contacts_per_page = 10;//1ページの表示件数
$this_page_url = basename(__FILE__);//file名
$page_number = 1;//現在のページ番号 初期値は1
$total_pages = 1;//総ページ数 初期値は1
$admin_mode = false;//管理モード初期は偽

//DB関係処理
$dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8',DB_HOST,DB_NAME);

session_start();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    //login
    if($_POST['adminpass'] === ADMINPASS){
        $_SESSION['adminpass'] = $_POST['adminpass'];
    }
    //logoff
    if($_POST['signout'] ==="signout"){
        unset($_SESSION['adminpass']);
    }
    //delete contact
    if(isset($_POST['del_id'])){
        //投稿の消去
        $pdo = new PDO($dsn,DB_USER,DB_PASSWORD);
        $stmt = $pdo -> prepare("DELETE FROM contact WHERE id = :id");
        $stmt->bindParam(':id', $_POST['del_id'], PDO::PARAM_INT);
        $stmt->execute();
    }
    header('location:./'.$this_page_url);
}else{
    if(isset($_SESSION['adminpass'])){
        $admin_mode = true;
    }

    //DB接続
    //page番号
    if(isset($_GET['page'])){
        $page_number = (int)$_GET['page'];
    }
    //DB接続
    try {
        $pdo = new PDO($dsn,DB_USER,DB_PASSWORD);

        //totalの件数を取得
        $stmt = $pdo -> prepare("select count(*) from contact");
        $stmt->execute();
        $total_contacts = $stmt->fetch();

        //総ページ数を計算
        if($total_contacts[0] > $contacts_per_page){
            $total_pages = ceil($total_contacts[0] / $contacts_per_page);
        }
        
        //総ページを上回るリクエスト対策
        if($page_number>$total_pages){
            header('location:'.ERROR_PAGE);
        };
        //var_dump($page_number,$total_pages);

        if($admin_mode){
            //投稿内容を取得
            $sql = "select * from contact limit :limit";
            if($page_number>1){
                $sql .= ' offset '.($page_number-1)*$contacts_per_page;
            }
            $stmt = $pdo -> prepare($sql);
            $stmt->bindParam(':limit', $contacts_per_page, PDO::PARAM_INT);
            $stmt->execute();
        }
    }catch(PDOException $e){
        //print('ERROR:'.$e->getMessage());
        header('location:'.ERROR_PAGE);
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>お問い合わせ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.min.css">
</head>
<body>
    <div class="container">
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <h1 class="navbar-item">
                Contact
                </h1>
            </div>   
            <div class="navbar-end">
            <form action="" method="post">
            <?php if(!$admin_mode) :?> 
                <div class="navbar-item">
                        <input class="input" type="password" name="adminpass" id="">
                        <button type="submit" class="button">sign in</button>
                </div>
            <?php else : ?>
                <div class="navbar-item">
                    <input type="hidden" name="signout" value="signout">
                    <button type="submit" class="button">sign out</button>
                </div>
            <?php endif; ?> 
                </form>
            </div>
        </nav>
        <h1 class="is-size-4">お問い合わせ一覧</h1>
        <?php if($total_contacts[0]>0 && $admin_mode):?>
            <table class="table is-fullwidth">
                <tr>
                    <th>ID</th>
                    <th>お名前</th>
                    <th>メール</th>
                    <th>内容</th>
                    <th>日付</th>
                    <th>削除</th>
                </tr>  
                <?php foreach($stmt as $loop):?>
                <tr>
                    <td><?= $loop['id'] ?></td>
                    <td><?= $loop['user_name'] ?></td>
                    <td><?= $loop['user_mail'] ?></td>
                    <td><?= $loop['message'] ?></td>
                    <td><?= $loop['created_at'] ?></td>
                    <td><form action="<?=$this_page_url?>" method="post"><input type="hidden" name="del_id" value="<?= $loop['id'] ?>"><button type="submit" class="button is-danger" onclick="return ck_cfm()">削除</button></form></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <nav class="pagination" role="navigation" aria-label="pagination">
                <ul class="pagination-list">
                    <?php foreach(range(1,$total_pages) as $num): ?>
                        <li><a class="pagination-link<?php if($num == $page_number) echo " is-current" ?>" href="<?php echo  $this_page_url; if($num != 1) echo "?page=".$num; ?>" aria-label="Goto page 2"><?= $num ?></a></li>
                    <?php endforeach; ?>
                    <!-- <a class="pagination-link is-current" aria-label="Page 1" aria-current="page">1</a> -->
                </ul>
            </nav>  
        <?php endif; ?>
        <script src="../js/submit.js"></script>
    </div>
</body>
</html>