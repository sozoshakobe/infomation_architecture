<?php
//日付を取得
$current = date("Y/m/d H:i:s");
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHPで日時表示
    </title>
    <link rel="stylesheet" href="css/bulma.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1  class="is-size-4">PHPで日時表示</h1>
        <div class="notification is-link" id="now"><?= $current ?></div>
        <a href="index.html" class="button is-info">>>戻る</a>
    </div>
</body>
</html>