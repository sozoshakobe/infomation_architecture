<?php
//table postsをリセット
define('USERNAME','');
define('PASSWORD','');
$pdo = new PDO("mysql:db_name=db_name;host=host_name",USERNAME,PASSWORD);
$stmt = $pdo->prepare("delete from posts");
$stmt->execute();
header('location:./data_store.php');