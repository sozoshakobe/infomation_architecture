create database if not exists mydata default charset utf8;
use mydata;
create table if not exists posts (id int primary key auto_increment,memo varchar(255), created_at datetime);
insert into posts (memo,created_at) values ('post_test001',now());