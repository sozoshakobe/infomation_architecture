<?php
//利用する変数を初期化
$url;
$method;
$data;
//処理
if($_SERVER['REQUEST_METHOD']==="GET"){
    $url = "requestGet.html"; 
    $data = $_GET['memo'];
    $method ="GET";
} else {
    $url = "requestPost.html"; 
    $data = $_POST['memo'];
    $method ="POST";
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTTP REQUEST RESULT</title>
    <link rel="stylesheet" href="css/bulma.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="is-size-4">HTTP REQUEST 送信結果</h1>
        <table class="table is-striped">
            <tr>
                <th>REQUEST METHOD</th>
                <td><?= $method ?></td>
            </tr>
            <tr>
                <th>送信内容</th>
                <td><?= $data ?></td>
            </tr>
        </table>
        <a href="<?= $url ?>" class="button is-info">>>戻る</a>
    </div>
</body>
</html>