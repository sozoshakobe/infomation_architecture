CREATE TABLE contact (
    id int primary key auto_increment,
    user_name varchar(255),
    user_mail varchar(255),
    message text,
    created_at datetime
) DEFAULT CHARSET=utf8;