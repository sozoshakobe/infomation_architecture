function ck_cfm(){
    const cfm = confirm('実行してもいいですか？');
    if(cfm){
        return true;
    }else{
        return false;
    }
}