<?php
define('USERNAME','root');
define('PASSWORD','root');
//DB接続
$pdo = new PDO("mysql:dbname=mydata;host=mysql",USERNAME,PASSWORD);
if($_SERVER['REQUEST_METHOD']==="POST"){
    //入力値をチェックしてDBに保存
    if(isset($_POST['memo']) && $_POST['memo']!="") {
        //DBに新規登録
        $stmt = $pdo->prepare("insert into posts (memo, created_at) VALUES (:memo, now())");
        $stmt->bindParam(':memo', htmlspecialchars($_POST['memo']), PDO::PARAM_STR);
        //$stmt->bindValue(':created_at', date, PDO::PARAM_INT);
        $stmt->execute();
    }
    header('location:'.$_SERVER['SCRIPT_NAME']);
}else{
    //DBから登録済の値を取得
    //prepareメソッドでSQLをセット
    $stmt = $pdo->prepare("select id, memo, created_at from posts order by id");
    //executeでクエリを実行
    $stmt->execute();
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>データの保存</title>
    <link rel="stylesheet" href="css/bulma.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="is-size-4">PHPでデータ記録</h1>
        <!--入力領域-->
        <form action="" method="post">
        <div class="control">
            <div class="columns">
                <div class="column">
                    <input class="input" type="text" name="memo" id="memo" placeholder="Normal input">
                </div>
                <div class="column">
                    <button class="button is-link" id="btn">記録</button>
                </div>
            </div>
        </div>
        </form>
        <!--表示領域-->
        <table class="table is-striped" id="dataTable">
        <?php foreach($stmt as $loop): ?>
            <tr>
                <td><?= $loop['id'] ?></td>
                <td><?= $loop['memo'] ?></td>
                <td><?= $loop['created_at'] ?></td>
            </tr>
        <?php endforeach; ?>
        </table>
        <a href="index.html" class="button is-info">>>戻る</a>
    </div>
</body>
</html>