<?php
//table postsをリセット
define('USERNAME','root');
define('PASSWORD','root');
$pdo = new PDO("mysql:dbname=mydata;host=mysql",USERNAME,PASSWORD);
$stmt = $pdo->prepare("delete from posts");
$stmt->execute();
header('location:/php/data_store.php');